import pickle
import torch
import numpy as np
import json
import scipy.io as sio


f = open("kaggle.valid.pkl","rb")
tutai=pickle.load(f)

print(tutai)
