#!/bin/bash

wget https://www2.cs.uic.edu/~vnoroozi/noisy-mnist/noisymnist_view1.gz
wget https://www2.cs.uic.edu/~vnoroozi/noisy-mnist/noisymnist_view2.gz
